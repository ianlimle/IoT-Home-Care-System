# -*- coding: utf-8 -*-
"""
Created on Sat Jun 30 22:08:56 2018

@author: BAI
"""

import kivy
from kivy.app import App
from kivy.lang import Builder
from kivy.clock import Clock
from kivy.graphics import Color
from kivy.properties import ObjectProperty
from kivy.core.window import Window
# widgets
from kivy.uix.widget import Widget
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.uix.switch import Switch
from kivy.uix.button import Button
from kivy.uix.slider import Slider
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.textinput import TextInput
# Sound
from kivy.core.audio import SoundLoader
# Layouts & screen manager
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
# non-kivy modules
import pickle
import math
import random
import time
import os.path

# Setup to exchange data through
# firebasefile:///C:/Users/BAI/Downloads/DW_1D_smart_window.py
from firebase import firebase
# firebasefile:///C:/Users/BAI/Downloads/DW_1D_smart_window.py
print('Setting up Firebase...', end='')
url = 'https://bosch-55278.firebaseio.com/'
token = 'cNPn9GlPATXPreFuNwULbsiB167fez6fY8SqdHeP'
firebase = firebase.FirebaseApplication(url, token)

kivy.require('1.10.0')

print('Setup Complete')

# # # Classes for the App # # #
class MainScreen(Screen):
    
    def __init__(self, **kwargs):
        super(MainScreen, self).__init__(**kwargs)
        self.currentUnit = self.ids['currentUnit']
        self.currentImg = self.ids['currentImg']
        self.currentTxt = self.ids['currentTxt']
        self.lastUpdateTime = self.ids['lastUpdateTime']
        self.magicBox = self.ids['magicBox']
        self.r1w0 = self.ids['r1w0']
        self.r1w1 = self.ids['r1w1']
        self.r1w2 = self.ids['r1w2']
        self.r1w3 = self.ids['r1w3']
        self.eventUpdate = Clock.schedule_interval(self.update, 6)
        self.alarm = SoundLoader.load("Eas Beep-SoundBible.com-238025417.mp3")
        
        self.audioActive = False
    
        self.deactivate = Button(size_hint= (0.8, 0.7), text = 'Deactivate', font_size = self.height/4.5)
        self.deactivate.bind(on_press=self.disappear)
        
    def update(self, instance, **kwargs):
        
        currentTime = int(time.time()) - int(time.time()) % 5
        namelist = firebase.get('/Bosch Data Repository')
        #print(namelist)
        namelist = list(namelist.keys())
        lastname = namelist.pop(len(namelist) -1)
        print(lastname)
        try:
            data = firebase.get('/Bosch Data Repository/{0}'.format(lastname))
            data = list(data.values())
        except:
            data = None
            print('no data recieved')
        try:
            data2 = firebase.get('/Bosch Data Repository/Light Fault')
            #data2 = True
            pass
        except:
            data2 = True
            print('no data2 recieved')
        try:
            data3 = firebase.get('/Bosch Data Repository/clutteredStatus')
        except:
            data3 = True
            print('no data3 recieved')
        
        # # Test Code # #
        if data == None:
            data = [10000 + random.randint(0,1), True, 10, True, 'Error', 'Disconnected']
            
        # # End of Test Code # #
        
        
        # # Convert the data # #
        print("light: {}  fall: {}  gas: {}  clutter: {}".format(data2,data[1],data[2],data3))
        audio = data[1]
        gas = data[2]
        if gas == 'true':
            gas = True
        elif gas == 'false':
            gas = False
        temp = 10
        if temp == 'NAN':
            temp = 0
            print('No temperature output')
        else:
            temp = float(temp)
        messy = data3
        
        fused = data2
        if fused == '1':
            fused = True
        elif fused == '0':
            fused = False
            
        # # End of conversion # #
        
        # # Update Timestamp of last updated time # #
        timing = lastname[1:]
        self.lastUpdateTime.text = 'Last  Update: {}'.format(timing)
        
        # # Conditons to update row 1 # #
        
        if fused:
            self.r1w0.source = 'fused.png'
        else:
            self.r1w0.source = 'none.png'
        
        if audio or self.audioActive:
            self.r1w3.source = 'loud.png'
            self.alarm.play()
            try:
                self.magicBox.remove_widget(self.deactivate)
            except:
                pass
            if self.currentUnit.text == '#02-01':
                self.magicBox.add_widget(self.deactivate)
            if audio:
                self.audioActive = True
            if gas:
                self.r1w2.source = 'gas.png'
                if messy:
                    self.r1w1.source = 'messy.png'
                else:
                    self.r1w1.source = 'none.png'
            else:
                self.r1w2.source = 'none.png'
                self.r1w1.source = 'none.png'
        elif gas:
            self.r1w3.source = 'gas.png'
            self.alarm.play()
            if messy:
                self.r1w2.source = 'messy.png'
                self.r1w1.source = 'none.png'
            else:
                self.r1w2.source = 'none.png'
                self.r1w1.source = 'none.png'
        elif messy:
            self.r1w3.source = 'messy.png'
        elif fused:
            self.r1w3.source = 'fused.png'
                
        # # Update Main display image # #
        
        if (self.currentUnit.text == "#02-01"):
            self.currentImg.source = self.r1w3.source
        else:
            self.currentImg.source = 'fine.png'
            
        # # Update Status Text # #
        if self.currentImg.source == 'loud.png':
            self.currentTxt.text = 'Status: IN DISTRESS'
        elif self.currentImg.source == 'gas.png':
            self.currentTxt.text = 'Status: GAS LEAK'
        elif self.currentImg.source == 'messy.png':
            self.currentTxt.text = 'Status: MESSY ROOM'
        elif self.currentImg.source == 'fused.png':
            self.currentTxt.text = 'Status: FUSED BULB'
        else:
            self.currentTxt.text = 'Status: Fine' 
            
        
#    def on_touch_down(self, instance):
#        print(self)
#        print(instance)
#        pass
    
    def disappear(self, instance):
        print('alarm deactivated')
        self.audioActive = False
        self.alarm.stop()
        self.magicBox.remove_widget(self.deactivate)
        self.update
        
    def change(self, unit):
        print('unit changed')
        self.currentUnit.text = unit
        try:
            self.magicBox.remove_widget(self.deactivate)
            if self.currentUnit.text == '#02-01' & self.audioActive:
                self.magicBox.add_widget(self.deactivate)
                
        except:
            pass
        
        
    
    # # Main app class # #


class BoschApp(App):
    # set the default window size
    Window.size = (547, 972)
    # change the default background colour of kivy
    Window.clearcolor = (66 / 255, 66 / 255, 66 / 255, 1)

    def build(self):
        # The screen manager
        myScreenManager = ScreenManager()
        myScreenManager.add_widget(MainScreen(name='main'))
        return myScreenManager


if __name__ == '__main__':
    BoschApp().run()
# # End of the App # #